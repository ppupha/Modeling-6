class ParameterError(ValueError):
    pass
